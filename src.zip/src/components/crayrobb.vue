<template>
    <div>
        <h1>最后疯抢</h1>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="sass" scoped>

</style>